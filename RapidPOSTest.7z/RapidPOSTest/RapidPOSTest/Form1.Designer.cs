﻿namespace RapidPOSTest
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dtpFromDate = new DateTimePicker();
            dtpToDate = new DateTimePicker();
            btnPrintSalesInfo = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // dtpFromDate
            // 
            dtpFromDate.Location = new Point(94, 54);
            dtpFromDate.Name = "dtpFromDate";
            dtpFromDate.Size = new Size(200, 23);
            dtpFromDate.TabIndex = 0;
            // 
            // dtpToDate
            // 
            dtpToDate.Location = new Point(94, 111);
            dtpToDate.Name = "dtpToDate";
            dtpToDate.Size = new Size(200, 23);
            dtpToDate.TabIndex = 1;
            // 
            // btnPrintSalesInfo
            // 
            btnPrintSalesInfo.Location = new Point(219, 149);
            btnPrintSalesInfo.Name = "btnPrintSalesInfo";
            btnPrintSalesInfo.Size = new Size(75, 23);
            btnPrintSalesInfo.TabIndex = 2;
            btnPrintSalesInfo.Text = "GO";
            btnPrintSalesInfo.UseVisualStyleBackColor = true;
            btnPrintSalesInfo.Click += btnPrintSalesInfo_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 62);
            label1.Name = "label1";
            label1.Size = new Size(40, 15);
            label1.TabIndex = 3;
            label1.Text = "FROM";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(43, 117);
            label2.Name = "label2";
            label2.Size = new Size(21, 15);
            label2.TabIndex = 4;
            label2.Text = "TO";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(106, 19);
            label3.Name = "label3";
            label3.Size = new Size(104, 15);
            label3.TabIndex = 5;
            label3.Text = "PRINT SALES INFO";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(342, 193);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnPrintSalesInfo);
            Controls.Add(dtpToDate);
            Controls.Add(dtpFromDate);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DateTimePicker dtpFromDate;
        private DateTimePicker dtpToDate;
        private Button btnPrintSalesInfo;
        private Label label1;
        private Label label2;
        private Label label3;
    }
}