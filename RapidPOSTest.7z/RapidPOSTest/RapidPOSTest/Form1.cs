using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data.SqlClient;
using System.Data;
using Newtonsoft.Json;
using Microsoft.VisualBasic.ApplicationServices;
using Newtonsoft.Json.Linq;

namespace RapidPOSTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string fromDate;
        string toDate;
        string json = string.Empty;
        List<object> objects = new List<object>();

        private void btnPrintSalesInfo_Click(object sender, EventArgs e)
        {
            fromDate = dtpFromDate.Value.ToString("yyyy-MM-dd");
            toDate = dtpToDate.Value.ToString("yyyy-MM-dd");

            //Connected in the DemoGolf database on the Server Explorer's Data Connections
            string connectionString = "Data Source=LAPTOP-7CV55SJQ\\SQLEXPRESS;Initial Catalog=DEMOGOLF;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("sp_GetSalesDetails", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@START_DATE", fromDate);
                cmd.Parameters.AddWithValue("@END_DATE", toDate);
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        IDictionary<string, object> record = new Dictionary<string, object>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            record.Add(reader.GetName(i), reader[i]);
                        }
                        objects.Add(record);
                    }
                }

                json = JsonConvert.SerializeObject(objects); //This is the Original Data pulled out from the stored procedure in Json format without the Profit Column
                

                ////////////////////////////////////////////
                //To add the Profit Column and it's values//
                ////////////////////////////////////////////
                
                DataTable dt = (DataTable)JsonConvert.DeserializeObject(json, (typeof(DataTable)));
                
                dt.Columns.Add("PROFIT", typeof(System.Int32)); //To Add the "Profit" Column

                foreach (DataRow row in dt.Rows) //To Add the Profit value to each row
                {
                    double cost;
                    double sales;

                    bool isSalesNumeric = double.TryParse((row["COST"].ToString()), out _); //To check if it has a numerical value or not NULL
                    if (isSalesNumeric)
                    {
                        sales = Convert.ToDouble(row["SALES"].ToString());
                    }

                    else
                    {
                        sales = 0; 
                    }

                    bool isCostNumeric = double.TryParse((row["COST"].ToString()), out _); //To check if it has a numerical value or not NULL
                    if (isCostNumeric)
                    {
                        cost = Convert.ToDouble(row["COST"].ToString());
                    }

                    else
                    {
                        cost = 0;
                    }
                    
                    row["PROFIT"] =  sales - cost;  //Calculates the profit and store the value in the Row
                }

                json = JsonConvert.SerializeObject(dt); //Json now with the Profit Column

                using (StreamWriter sw = new StreamWriter(File.Create("D:\\test.txt"))) //To put the Json on a File in a specific location
                {
                    sw.Write(json);
                }

                con.Close();
            }
        }
    }
}